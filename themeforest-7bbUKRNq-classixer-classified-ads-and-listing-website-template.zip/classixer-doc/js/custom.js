$(function() {
"use strict";
    
    //$('#nav').onePageNav();
    
    $( "#welcome" ).tabs();

});